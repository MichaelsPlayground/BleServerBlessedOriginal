# bluetooth-server-example
Example that shows how to implement a Bluetooth Peripheral on a phone
