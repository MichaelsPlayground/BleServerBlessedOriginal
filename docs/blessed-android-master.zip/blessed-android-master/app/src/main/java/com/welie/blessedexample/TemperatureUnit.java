package com.welie.blessedexample;

public enum TemperatureUnit {
    Celsius,
    Fahrenheit
}
